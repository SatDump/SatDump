#pragma once

#include <cstdint>

namespace goes
{
    namespace hrit
    {
        int ID_HIMAWARI8 = 43;
    }
}