This was adapted from https://gitlab.eumetsat.int/open-source/PublicDecompWT. And as the Apache-2.0 License is compatible with GPL-3.0, was included there.
All credits go to EUMETSAT for writing this code.

Unecessary files were removed, some code was modified to better suit my purpose and a bunch of warnings were removed.