#pragma once

#include <cstdint>

namespace meteor
{
    namespace msumr
    {
        namespace lrpt
        {
            void Idct(int64_t *src);
        }
    } // namespace msumr
} // namespace meteor